
 <?php
 
$company = $_GET["symbol"];
			
echo "<root><Name>$company</Name></root>";

?>